import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasherBasicInfoComponent } from './washer-basic-info.component';

describe('WasherBasicInfoComponent', () => {
  let component: WasherBasicInfoComponent;
  let fixture: ComponentFixture<WasherBasicInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasherBasicInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherBasicInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

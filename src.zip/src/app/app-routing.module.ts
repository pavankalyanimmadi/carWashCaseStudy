import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { CustomerOngoingRequestsComponent } from './customer-ongoing-requests/customer-ongoing-requests.component';
import { HeadNavComponent } from './head-nav/head-nav.component';
import { WashpackagesComponent } from './washpackages/washpackages.component';
import { CustomerRaiseRequestComponent } from './customer-raise-request/customer-raise-request.component';
import { CustomerInProgressReqComponent } from './customer-in-progress-req/customer-in-progress-req.component';
import { CustomerPastRequestsComponent } from './customer-past-requests/customer-past-requests.component';
import { WasherAwaitingDealsComponent } from './washer-awaiting-deals/washer-awaiting-deals.component';
import { WasherInProgressReqComponent } from './washer-in-progress-req/washer-in-progress-req.component';
import { WasherPreviousReqComponent } from './washer-previous-req/washer-previous-req.component';
import { PaymentcheckoutComponent } from './paymentcheckout/paymentcheckout.component';
import { PaymentmethodsComponent } from './paymentmethods/paymentmethods.component';
import { ProfileComponent } from './profile/profile.component';
import { CustomerpackgesinfoComponent } from './customerpackgesinfo/customerpackgesinfo.component';
import { AddingcarsComponent } from './addingcars/addingcars.component';
import { CustomerCarsComponent } from './customer-cars/customer-cars.component';
import { FeebbackComponent } from './feebback/feebback.component';
import { AdminAllCustomersComponent } from './admin-all-customers/admin-all-customers.component';
import { AdminAllWashersComponent } from './admin-all-washers/admin-all-washers.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'customerrequests', component: CustomerOngoingRequestsComponent },
  {path: 'washpackages', component: WashpackagesComponent},
  {path: 'customerraisingrequest',component: CustomerRaiseRequestComponent},
  {path:'customerinprogressrequests', component: CustomerInProgressReqComponent},
  {path:'customerPastRequests', component: CustomerPastRequestsComponent},
  {path:'awaitingorders', component: WasherAwaitingDealsComponent},
  {path:'washerinprogrsreq', component: WasherInProgressReqComponent},
  {path:'washerpostorders',component:WasherPreviousReqComponent},
  {path:'payment', component:PaymentcheckoutComponent},
  {path:'paymentmethods', component:PaymentmethodsComponent},
  {path:'profile', component:ProfileComponent},
  {path:'customerpackages',component:CustomerpackgesinfoComponent},
  {path:'adddingcars', component:AddingcarsComponent},
  {path:'viewingcars',component:CustomerCarsComponent},
  {path:'feeback',component:FeebbackComponent},
  {path:'getallcustomers',component:AdminAllCustomersComponent},
  {path:'getallwashers',component:AdminAllWashersComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{
    onSameUrlNavigation: 'reload'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }

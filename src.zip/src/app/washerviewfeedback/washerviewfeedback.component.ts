import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { WasherPreviousReqComponent } from '../washer-previous-req/washer-previous-req.component';
import { WasherService } from '../washer.service';

@Component({
  selector: 'app-washerviewfeedback',
  templateUrl: './washerviewfeedback.component.html',
  styleUrls: ['./washerviewfeedback.component.css']
})
export class WasherviewfeedbackComponent implements OnInit {

  constructor(private  washerService:WasherService,public dialogRef: MatDialogRef<WasherPreviousReqComponent>) { }

  selectedOrder:any;
  ngOnInit(): void {
    this.selectedOrder=this.washerService.selectedOrderforviewingFeedback;
  }

  getback()
  {
    this.dialogRef.close();
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WasherviewfeedbackComponent } from './washerviewfeedback.component';

describe('WasherviewfeedbackComponent', () => {
  let component: WasherviewfeedbackComponent;
  let fixture: ComponentFixture<WasherviewfeedbackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WasherviewfeedbackComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherviewfeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

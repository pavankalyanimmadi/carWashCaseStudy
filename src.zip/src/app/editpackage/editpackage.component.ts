import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpackage',
  templateUrl: './editpackage.component.html',
  styleUrls: ['./editpackage.component.scss']
})
export class EditpackageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

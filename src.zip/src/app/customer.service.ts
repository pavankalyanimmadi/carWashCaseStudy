import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './Cusomer';
import { Car } from './Car';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  loggedPerson:Customer=new Customer();
  order:any;
  selectedCarForWash:Car;
  isSelectedCar:boolean=false;
  isselectedpackage:boolean=false;
  selectedpackgeforwash:any;

  constructor(private http: HttpClient) { }


  public saveselctedpackageforwash(pack)
  { 
    this.isselectedpackage=true;
     this.selectedpackgeforwash=pack;
  }

  public customerlogin(customer){
    return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/login",customer);
  }

  public customerSignup(customer){
    return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/signup",customer); 
  }


  public customerRaiseRequest(order)
  {
    return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/raisewashrequest",order);

  }


  public customerInprogress(id)
  {
    return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/inprogressorders",id)

  }


  public customeroldrequests(id)
  {
    return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/servedorders",id) 

  }

  saveLoggedPerson(cus)
  {
    this.loggedPerson=cus;
  }


  addingcarDetails(car:Car,image:File)
  {
    const formdata: FormData = new FormData();
    formdata.append('car', JSON.stringify(car));
    formdata.append('file', image);
    return this.http.post("http://localhost:8889/addingcardeatils",formdata); 
  }

  saveOrderFormakePayment(order)
  {
       this.order=order;

  }

  selectedcar(car)
  {
    this.isSelectedCar=true;
       this.selectedCarForWash=car;
  }

  makepayment(payment)
  {
    return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/payment",payment)
  }

  savingfeedback(order)
  {

    return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/feedback",order)

  }



  deletecar(car)
  {
      return this.http.post("https://yurbonvhu5.execute-api.us-east-1.amazonaws.com/dev/deletecar",car);
  }

  getAllPackages()
  {
    return this.http.get("https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/viewallwashpackages"); 
  }

  editProfiile(customer)
  {
    return this.http.post("http://localhost:8889/updateprofile",customer); 

  }

  }




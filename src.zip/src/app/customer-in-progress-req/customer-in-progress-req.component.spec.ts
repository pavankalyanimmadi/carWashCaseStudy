import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerInProgressReqComponent } from './customer-in-progress-req.component';

describe('CustomerInProgressReqComponent', () => {
  let component: CustomerInProgressReqComponent;
  let fixture: ComponentFixture<CustomerInProgressReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerInProgressReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerInProgressReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

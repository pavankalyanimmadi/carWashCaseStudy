import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeadNavComponent } from './head-nav/head-nav.component';
import { LayoutModule } from '@angular/cdk/layout'; 
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import {MatMenuModule} from '@angular/material/menu';
import {MatTableModule} from '@angular/material/table';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatCardModule} from '@angular/material/card';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';

import {MatDialogModule} from '@angular/material/dialog'

import { NgbModule } from '@ng-bootstrap/ng-bootstrap'; 








import {HttpClientModule} from '@angular/common/http';
import { CustomerOngoingRequestsComponent } from './customer-ongoing-requests/customer-ongoing-requests.component';
import { CustomerBasicInfoComponent } from './customer-basic-info/customer-basic-info.component';
import { CustomerCarsComponent } from './customer-cars/customer-cars.component';
import { CustomerInProgressReqComponent } from './customer-in-progress-req/customer-in-progress-req.component';
import { CustomerPastRequestsComponent } from './customer-past-requests/customer-past-requests.component';
import { CustomerRaiseRequestComponent } from './customer-raise-request/customer-raise-request.component';
import { WasherBasicInfoComponent } from './washer-basic-info/washer-basic-info.component';
import { WasherInProgressReqComponent } from './washer-in-progress-req/washer-in-progress-req.component';
import { WasherAwaitingDealsComponent } from './washer-awaiting-deals/washer-awaiting-deals.component';
import { WasherPreviousReqComponent } from './washer-previous-req/washer-previous-req.component';
import { AdminAllCustomersComponent } from './admin-all-customers/admin-all-customers.component';
import { AdminAllWashersComponent } from './admin-all-washers/admin-all-washers.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { MatOptionModule } from '@angular/material/core';
import { WashpackagesComponent } from './washpackages/washpackages.component';
import { AddnewpackageComponent } from './addnewpackage/addnewpackage.component';
import { EditpackageComponent } from './editpackage/editpackage.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTimepickerModule } from 'mat-timepicker';


import { HammerModule } from "@angular/platform-browser";
import { HomecorousalComponent } from './homecorousal/homecorousal.component';
import { PaymentcheckoutComponent } from './paymentcheckout/paymentcheckout.component';
import { PaymentmethodsComponent } from './paymentmethods/paymentmethods.component';
import { ProfileComponent } from './profile/profile.component';
import { CustomerpackgesinfoComponent } from './customerpackgesinfo/customerpackgesinfo.component';
import { AddingcarsComponent } from './addingcars/addingcars.component';
import { FeebbackComponent } from './feebback/feebback.component';
import { WasherviewfeedbackComponent } from './washerviewfeedback/washerviewfeedback.component';





@NgModule({
  declarations: [
    AppComponent,
    HeadNavComponent,
    LoginComponent,
    SignupComponent,
    CustomerOngoingRequestsComponent,
    CustomerBasicInfoComponent,
    CustomerCarsComponent,
    CustomerInProgressReqComponent,
    CustomerPastRequestsComponent,
    CustomerRaiseRequestComponent,
    WasherBasicInfoComponent,
    WasherInProgressReqComponent,
    WasherAwaitingDealsComponent,
    WasherPreviousReqComponent,
    AdminAllCustomersComponent,
    AdminAllWashersComponent,
    WashpackagesComponent,
    AddnewpackageComponent,
    EditpackageComponent,
    HomecorousalComponent,
    PaymentcheckoutComponent,
    PaymentmethodsComponent,
    ProfileComponent,
    CustomerpackgesinfoComponent,
    AddingcarsComponent,
    FeebbackComponent,
    WasherviewfeedbackComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatCardModule,
    MatTableModule,
    MatDividerModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTimepickerModule,
    NgbModule
    

    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homecorousal',
  templateUrl: './homecorousal.component.html',
  styleUrls: ['./homecorousal.component.scss']
})
export class HomecorousalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

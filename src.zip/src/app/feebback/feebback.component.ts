import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomerService } from '../customer.service';
import { WashOrder } from '../WashOrder';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feebback',
  templateUrl: './feebback.component.html',
  styleUrls: ['./feebback.component.css']
})
export class FeebbackComponent implements OnInit {
  form:FormGroup;
  currentSelectedOrder:any;
  order:WashOrder=new WashOrder();

  constructor(private fb:FormBuilder,private cusService:CustomerService,private route:Router) { }

  ngOnInit(): void {
    this.form=this.fb.group({
      rating:['',Validators.required],
      comments:['']

    });

    this.currentSelectedOrder=this.cusService.order
  }

  submit()
  {
    
    console.log(this.form.value);
    this.currentSelectedOrder.rating=this.form.get("rating").value;
    this.currentSelectedOrder.comments=this.form.get("comments").value;
    this.cusService.savingfeedback(this.currentSelectedOrder).subscribe((data)=>{
      if(data!=null){
        this.route.navigateByUrl('customerPastRequests');
      }
    })


  }

  getback()
  {
    this.route.navigateByUrl('customerPastRequests')
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerpackgesinfoComponent } from './customerpackgesinfo.component';

describe('CustomerpackgesinfoComponent', () => {
  let component: CustomerpackgesinfoComponent;
  let fixture: ComponentFixture<CustomerpackgesinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerpackgesinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerpackgesinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

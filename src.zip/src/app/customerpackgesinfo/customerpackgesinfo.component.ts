import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customerpackgesinfo',
  templateUrl: './customerpackgesinfo.component.html',
  styleUrls: ['./customerpackgesinfo.component.scss']
})
export class CustomerpackgesinfoComponent implements OnInit {

  allPackages:any=[{}]

  constructor(private customerService:CustomerService,private route:Router) { }

  ngOnInit(): void {
    this.customerService.getAllPackages().subscribe((data)=>{
      this.allPackages=data
      console.log(this.allPackages);

    })

    


  }

  packageselected(pack)
    {
      this.customerService.saveselctedpackageforwash(pack);
      this.route.navigateByUrl('customerraisingrequest');
      
          
    }

}

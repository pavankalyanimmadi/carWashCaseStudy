import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {CustomerService} from '../customer.service'
import {WasherService} from '../washer.service'
import {AdminService} from '../admin.service'
import {Customer} from '../Cusomer'

let responsedata:any=null;

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  form:FormGroup;
  regFailed:boolean=false;
  response:any;
  
 

  customer:Customer=new Customer();



  constructor(private fb:FormBuilder,private route:Router,private custService:CustomerService,private washerService:WasherService) { 
  }

  ngOnInit(): void {
    this.form=this.fb.group({
      role:['',Validators.required],
      name:['',Validators.required],
      phonenumber:['',Validators.required],
      address:['',Validators.required],
      
      username: ['', Validators.email],
      password: ['', Validators.required] 

    });

  }

  onSubmit(){
   if(this.form.valid){
     this.customer.address=this.form.get('address').value;
     this.customer.emailId=this.form.get('username').value;
     this.customer.mobileNumber=this.form.get('phonenumber').value;
     this.customer.name=this.form.get('name').value;
     this.customer.password=this.form.get('password').value;
     this.customer.phoneNumber=this.form.get('phonenumber').value;

     if(this.form.get('role').value=='customer'){
      this.custService.customerSignup(this.customer).subscribe((data)=>{
        console.log(data);
        this.response=data
        responsedata=data;
        if(this.response.registrationStatus==false){
          
          this.regFailed=true;
           this.route.navigateByUrl('signup')
           
           
 
         }
         else{
           this.route.navigateByUrl('login')
         }

        


       });
      }

      if(this.form.get('role').value=='washer'){
        this.washerService.washersignup(this.customer).subscribe((data)=>{
          this.response=data;
          console.log(data)
          responsedata=data;
          if(this.response.registrationStatus==false){
          
            this.regFailed=true;
             this.route.navigateByUrl('signup')
             
             
   
           }
           else{
             this.route.navigateByUrl('login')
           }



         });
        }

       
     
     




   }


  }

}

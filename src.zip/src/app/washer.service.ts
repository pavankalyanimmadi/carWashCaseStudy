import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './Cusomer';

@Injectable({
  providedIn: 'root'
})
export class WasherService {

  loggedPerson:Customer=new Customer();
  selectedOrderforviewingFeedback:any;



  constructor(private http:HttpClient) { }

  saveSelectedOrderForviewingFeedback(order)
  {
      this.selectedOrderforviewingFeedback=order;
  }

  washerlogin(washer){
    return this.http.post("https://yoffvz50q3.execute-api.us-east-1.amazonaws.com/dev/login",washer);
  }

  washersignup(washer){
    return this.http.post("https://yoffvz50q3.execute-api.us-east-1.amazonaws.com/dev/signup",washer);
  }


  washerviewingallrequests()

  {
     return this.http.get("https://yoffvz50q3.execute-api.us-east-1.amazonaws.com/dev/viewingawaitingdeals")

  }

  washeracceptingorder(order)
  {
      return this.http.post("https://yoffvz50q3.execute-api.us-east-1.amazonaws.com/dev/acceptingorders",order)
  }

  washerorderserved(order)
  {
    return this.http.post("https://yoffvz50q3.execute-api.us-east-1.amazonaws.com/dev/closingorder",order)
  }


  
  washerInprogress(id)
  {
      return this.http.post("https://yoffvz50q3.execute-api.us-east-1.amazonaws.com/dev/inprogressorders",id)
  }

  washeroldrequests(id)
  {
      return this.http.post("https://yoffvz50q3.execute-api.us-east-1.amazonaws.com/dev/servedorders",id)
  }

  saveLoggedPerson(person)
  {
      this.loggedPerson=person;
  }
  updateprofile(person)
  {
       return this.http.post("http://localhost:9998/updateprofile",person)
  }


}

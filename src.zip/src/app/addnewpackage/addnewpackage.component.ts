import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AdminService } from '../admin.service';
import { WashPackage } from '../washPackage';
import { WashpackagesComponent } from '../washpackages/washpackages.component';

@Component({
  selector: 'app-addnewpackage',
  templateUrl: './addnewpackage.component.html',
  styleUrls: ['./addnewpackage.component.scss']
})
export class AddnewpackageComponent implements OnInit {
  form:FormGroup;
  washPackage:WashPackage=new WashPackage();

  constructor(private adminService:AdminService,public dialogRef: MatDialogRef<WashpackagesComponent>,private fb:FormBuilder) { }

  ngOnInit(): void {
    this.form=this.fb.group({
      packageName:['',Validators.required],
      packageDescription:['',Validators.required],
      packageCost:['',Validators.required]

    })
  }

  savePackage()
  {
    console.log(this.form.value);
    this.washPackage.packageCost=this.form.get('packageCost').value
    this.washPackage.packageDescription=this.form.get('packageDescription').value
    this.washPackage.packageName=this.form.get('packageName').value
    this.adminService.addPackage(this.washPackage).subscribe((data)=>{
      if(data!=null)
      {
        this.dialogRef.close();
      }
    })
  }

  onclose()
  {
    this.dialogRef.close()
  }



}

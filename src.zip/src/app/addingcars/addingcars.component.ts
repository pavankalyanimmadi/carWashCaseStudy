import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {Car} from '../Car'
import {CustomerService} from '../customer.service'
import { MatDialogRef } from '@angular/material/dialog';
import { CustomerCarsComponent } from '../customer-cars/customer-cars.component';

@Component({
  selector: 'app-addingcars',
  templateUrl: './addingcars.component.html',
  styleUrls: ['./addingcars.component.scss']
})
export class AddingcarsComponent implements OnInit {

  form:FormGroup;
   carImage:any;
   car:Car=new Car();


  constructor(private fb:FormBuilder,private customerService:CustomerService,public dialogRef: MatDialogRef<CustomerCarsComponent>) { }

  ngOnInit(): void {
    this.form=this.fb.group({
      carBrandName:['',Validators.required],
      carModel:['',Validators.required],
      carNumber:['',Validators.required]

    });

  }

  onFileChanged(event) {
    this.carImage= event.target.files[0]
  }

  onSubmit()
  {
    this.car.carModel=this.form.get('carModel').value;
    this.car.carNumber=this.form.get('carNumber').value;
    this.car.carBrandName=this.form.get('carBrandName').value;
    this.car.customerId=localStorage.getItem('id');
    
    this.customerService.addingcarDetails(this.car,this.carImage).subscribe((data)=>{
      if(data!=null)
      {
        this.customerService.saveLoggedPerson(data);
        console.log(data);
        this.dialogRef.close();
        
      }
    })

    



    


  }

  onclose()
  {
     this.dialogRef.close();
  }


}

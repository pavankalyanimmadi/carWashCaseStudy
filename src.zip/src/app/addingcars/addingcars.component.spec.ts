import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddingcarsComponent } from './addingcars.component';

describe('AddingcarsComponent', () => {
  let component: AddingcarsComponent;
  let fixture: ComponentFixture<AddingcarsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddingcarsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddingcarsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

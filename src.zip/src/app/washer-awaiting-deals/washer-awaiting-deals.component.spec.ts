import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasherAwaitingDealsComponent } from './washer-awaiting-deals.component';

describe('WasherAwaitingDealsComponent', () => {
  let component: WasherAwaitingDealsComponent;
  let fixture: ComponentFixture<WasherAwaitingDealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasherAwaitingDealsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherAwaitingDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

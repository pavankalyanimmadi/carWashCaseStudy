import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {WasherService} from '../washer.service'
import {Customer} from '../Cusomer'
import { Router } from '@angular/router'; 
import {Location} from '@angular/common'

@Component({
  selector: 'app-washer-awaiting-deals',
  templateUrl: './washer-awaiting-deals.component.html',
  styleUrls: ['./washer-awaiting-deals.component.scss']
})
export class WasherAwaitingDealsComponent implements OnInit {

  displayedColumns: string[] = ['carModel','carNumber','orderPackageName','orderPackageDescription','orderPackagePrice','customerName','customerPhoneNumber','location','accept',];
  dataSource:MatTableDataSource<any>;
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();
  searchKey:string;
  data:any;
  
  /*[{carModel:"ford",carNumber:"dsf43",orderPackageName:"gold",orderPackageDescription:"fgxdfgs",orderPackagePrice:"3453",customerName:"sdfzsd",customerPhoneNumber:"456456456",location:"fdkgdfh"},
  {carModel:"ferrari",carNumber:"fsd434",orderPackageName:"diamond",orderPackageDescription:"fgxdfgs",orderPackagePrice:"3453",customerName:"SZCSz",customerPhoneNumber:"435345",location:"sdzfd"} 
 ]*/



  constructor(private washerService:WasherService, private route:Router,private location:Location) { }

  ngOnInit(): void {
   this.gettingdata();

    
  }

   gettingdata()
   {
    this.washerService.washerviewingallrequests().subscribe((data)=>{
      this.data=data;
      console.log(data)
      this.dataSource=new MatTableDataSource(this.data);
    })

   }





  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    console.log(searchKey)
    this.dataSource.filter = searchKey.trim().toLowerCase();
    console.log("in data source  "+ this.dataSource.filter)
  }

  accept(deal)
  {
    
    console.log(deal)
    deal.washerId=localStorage.getItem('id');

    this.washerService.washeracceptingorder(deal).subscribe((data)=>{
     if(data!=null)
     {
       console.log("in response");
       console.log(data);
       this.gettingdata();
       this.getLoggedInName.emit(); 
     // this.route.navigateByUrl('awaitingorders'); 
       
      
    
       
     }

    })

  }




}

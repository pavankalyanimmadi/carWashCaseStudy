import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {Customer} from '../Cusomer';
import {CustomerService} from '../customer.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-past-requests',
  templateUrl: './customer-past-requests.component.html',
  styleUrls: ['./customer-past-requests.component.scss']
})
export class CustomerPastRequestsComponent implements OnInit {

  displayedColumns: string[] = ['carModel','carNumber','orderPackageName','orderPackagePrice','washerName','washerPhoneNumber','payment','rating'];
  dataSource:MatTableDataSource<any>;
  searchKey:string;
  data:any;
  
  
  
/*  [{carModel:"ford",carNumber:"far3",orderPackageName:"gold",orderPackagePrice:"3453",washerName:"sdfzsd",washerPhoneNumber:"456456456",payment:"done through ***5678",rating:"5"},
  {carModel:"ferrari",carNumber:"sadf43",orderPackageName:"diamond",orderPackagePrice:"546546645",washerName:"234534",washerPhoneNumber:"675656",payment:"done through ***8903",rating:"4"} 
 ]*/


 customer:Customer=new Customer( );




  constructor(private cusService:CustomerService, private route:Router) { }

  ngOnInit(): void {
    this.customer.emailId=localStorage.getItem('id');
    this.cusService.customeroldrequests(this.customer).subscribe((data)=>{

      this.data=data;
      console.log(data);
      this.dataSource=new MatTableDataSource(this.data);
    })


   

  }

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    console.log(searchKey)
    this.dataSource.filter = searchKey.trim().toLowerCase();
    console.log("in data source  "+ this.dataSource.filter)
  }

  makePayment(element)
  {
    this.cusService.saveOrderFormakePayment(element);
    this.route.navigateByUrl('payment')
  }

  editrating(order)
  {
         this.cusService.order=order;
       console.log(order);
       this.route.navigateByUrl('feeback')
  }




}

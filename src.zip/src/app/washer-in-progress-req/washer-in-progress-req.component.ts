import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {WasherService} from '../washer.service'
import {Customer} from '../Cusomer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-washer-in-progress-req',
  templateUrl: './washer-in-progress-req.component.html',
  styleUrls: ['./washer-in-progress-req.component.scss']
})
export class WasherInProgressReqComponent implements OnInit {

  displayedColumns: string[] = ['carModel','carNumber','orderPackageName','orderPackageDescription','orderPackagePrice','customerName','customerPhoneNumber','location','orderStatus',];
  dataSource:MatTableDataSource<any>;
  searchKey:string;
  data:any;
  customer:Customer=new Customer();
  @Output() refresh: EventEmitter<any> = new EventEmitter();
  
  /*[{carModel:"ford",carNumber:"dsf43",orderPackageName:"gold",orderPackageDescription:"fgxdfgs",orderPackagePrice:"3453",customerName:"sdfzsd",customerPhoneNumber:"456456456",location:"fdkgdfh",status:"In Progress"},
  {carModel:"ferrari",carNumber:"fsd434",orderPackageName:"diamond",orderPackageDescription:"fgxdfgs",orderPackagePrice:"3453",customerName:"SZCSz",customerPhoneNumber:"435345",location:"sdzfd",status:"In Progrss"} 
 ]*/


  constructor(private washerService:WasherService,private route:Router) { }

  ngOnInit(): void {

   this.getdata();

    
  }

  getdata()
  {
    this.customer.emailId=localStorage.getItem('id');
    this.washerService.washerInprogress(this.customer).subscribe((data)=>{
      this.data=data;
      console.log(data);
      this.dataSource=new MatTableDataSource(this.data);
    })

  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    console.log(searchKey)
    this.dataSource.filter = searchKey.trim().toLowerCase();
    console.log("in data source  "+ this.dataSource.filter)
  }



  statusupdate(order)
  {
       this.washerService.washerorderserved(order).subscribe((data)=>{
         if(data!=null)
         {
           console.log(data);
           this.getdata();
          // this.route.navigateByUrl('/washerinprogrsreq');
          this.refresh.emit();
            
          // this.refresh.emit();
 
         }
       })
  }




}

export class WashOrder
{
    pakcageId:string;
    date:any;
    time:any;
    location:string;
    carModel:string;
    carNumber:string;
    customerId:string;

    rating:number;
    comments:String;

}
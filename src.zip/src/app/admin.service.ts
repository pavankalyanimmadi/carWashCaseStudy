import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './Cusomer';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  loggedPerson:Customer=new Customer();


  editPackage:any;

  constructor(private http:HttpClient) { }

  adminlogin(admin){
    return this.http.post("https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/login",admin);
  }


  getAllPackages()
  {
    return this.http.get("https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/viewallwashpackages"); 
  }

  storeEditPckage(pack){
    this.editPackage=pack;
  }

  deletePackage(pack)
  {
    return this.http.post("https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/deletepackage ",pack); 

  }

  saveLoggedPerson(per)
  {
     this.loggedPerson=per;
  }

addPackage(pack)
{
   return this.http.post(" https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/addpackage",pack)
}

getallCusttomers()
{
  return this.http.get(" https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/viewallcutsomers")
}

deleteCustomer(customer)
{
  return this.http.post("https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/deletecustomer",customer)
}

deletewasher(washer)
{
    return this.http.post("https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/deletewasher",washer);
}

getAllWashers()
{
  return this.http.get("https://w17dxo1xuh.execute-api.us-east-1.amazonaws.com/dev/viewallwashers")
}



}

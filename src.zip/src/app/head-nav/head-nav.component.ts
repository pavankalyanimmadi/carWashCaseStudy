import { Component, ChangeDetectorRef } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-head-nav',
  templateUrl: './head-nav.component.html',
  styleUrls: ['./head-nav.component.scss']
})
export class HeadNavComponent {

  loggedPersonName:String;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private breakpointObserver: BreakpointObserver,iconRegistry: MatIconRegistry,private changeDetector:ChangeDetectorRef, 
    sanitizer: DomSanitizer,private route:Router) {
      iconRegistry.addSvgIcon(
        'menu',
        sanitizer.bypassSecurityTrustResourceUrl('assets/menu.svg'));
      
      iconRegistry.addSvgIcon(
        'account',
        sanitizer.bypassSecurityTrustResourceUrl('assets/account.svg'));

        iconRegistry.addSvgIcon(
          'signup',
          sanitizer.bypassSecurityTrustResourceUrl('assets/signup.svg'));

        iconRegistry.addSvgIcon(
          'login',
          sanitizer.bypassSecurityTrustResourceUrl('assets/login.svg'));

        iconRegistry.addSvgIcon(
            'add',
            sanitizer.bypassSecurityTrustResourceUrl('assets/add.svg'));
        iconRegistry.addSvgIcon(
              'delete',
          sanitizer.bypassSecurityTrustResourceUrl('assets/delete.svg'));
        iconRegistry.addSvgIcon(
            'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'edit',
      sanitizer.bypassSecurityTrustResourceUrl('assets/edit.svg'));
      iconRegistry.addSvgIcon(
        'select',
        sanitizer.bypassSecurityTrustResourceUrl('assets/select.svg'));
        iconRegistry.addSvgIcon(
          'cart',
          sanitizer.bypassSecurityTrustResourceUrl('assets/cart.svg'));
          iconRegistry.addSvgIcon(
            'verified',
          sanitizer.bypassSecurityTrustResourceUrl('assets/verified.svg'));
          iconRegistry.addSvgIcon(
            'track',
          sanitizer.bypassSecurityTrustResourceUrl('assets/track.svg'));

          localStorage.setItem('role',"empty");
          this.loggedPersonName="__"+localStorage.getItem('name');
          console.log(this.loggedPersonName)
        }


      
    readvalues()
        {
            if(localStorage.getItem('role')=="empty")   {
              return "false";
            }     
            else{
              return "true"
            }  
            
        }

        read()
        {
          return localStorage.getItem('role'); 
         // return "washer";
        }

        cart()
        {
          this.route.navigateByUrl('customerrequests');
        }

        logout(){
          localStorage.setItem('role',"empty");
          localStorage.setItem('id',"");
          localStorage.removeItem('name')
          

          this.route.navigateByUrl('')
        }

}

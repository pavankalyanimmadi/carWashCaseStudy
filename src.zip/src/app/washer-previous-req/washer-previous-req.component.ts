import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import {Customer} from '../Cusomer'
import {WasherService} from '../washer.service'
import { WasherviewfeedbackComponent } from '../washerviewfeedback/washerviewfeedback.component';

@Component({
  selector: 'app-washer-previous-req',
  templateUrl: './washer-previous-req.component.html',
  styleUrls: ['./washer-previous-req.component.scss']
})
export class WasherPreviousReqComponent implements OnInit {

  displayedColumns: string[] = ['carModel','carNumber','orderPackageName','orderPackagePrice','customerName','customerPhoneNumber','location','FeedBack',];
  dataSource:MatTableDataSource<any>;
  searchKey:string;
  data:any;
  customer:Customer=new Customer();
  
  
  /*[{carModel:"ford",carNumber:"dsf43",orderPackageName:"gold",orderPackageDescription:"fgxdfgs",orderPackagePrice:"3453",customerName:"sdfzsd",customerPhoneNumber:"456456456",location:"fdkgdfh",rated:"5"},
  {carModel:"ferrari",carNumber:"fsd434",orderPackageName:"diamond",orderPackageDescription:"fgxdfgs",orderPackagePrice:"3453",customerName:"SZCSz",customerPhoneNumber:"435345",location:"sdzfd",rated:"4"} 
 ]*/

 

  constructor(private washerService:WasherService, public dialog: MatDialog) { }

  ngOnInit(): void {
   this.customer.emailId=localStorage.getItem('id')
   this.washerService.washeroldrequests(this.customer).subscribe((data)=>{
     this.data=data;
     this.dataSource=new MatTableDataSource(this.data);
     console.log(data)
   })

    
  }


  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    console.log(searchKey)
    this.dataSource.filter = searchKey.trim().toLowerCase();
    console.log("in data source  "+ this.dataSource.filter)
  }

  viewfeedback(element)
  {
    console.log(element);
    this.washerService.saveSelectedOrderForviewingFeedback(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    
    this.dialog.open(WasherviewfeedbackComponent,dialogconfig);



  }

}

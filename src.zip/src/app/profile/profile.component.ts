import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../Cusomer';
import { CustomerService } from '../customer.service';
import { WasherService } from '../washer.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {


  loggedPerson:Customer=new Customer();
  loggedPersonRole:string;
  form:FormGroup;
  savedchanges:boolean=false;
  EditMode:boolean=false;
  customer:Customer=new Customer();

  constructor(private customerService:CustomerService,private washerservice:WasherService,private fb:FormBuilder,private route:Router) { }

  ngOnInit(): void {
    this.loggedPersonRole=localStorage.getItem('role');
    if(this.loggedPersonRole=="customer")
    {
      this.loggedPerson=this.customerService.loggedPerson;
    }

    if(this.loggedPersonRole=="washer")

    {
      this.loggedPerson=this.washerservice.loggedPerson
    }

    this.form=this.fb.group({
      role:['',Validators.required],
      name:['',Validators.required],
      phonenumber:['',Validators.required],
      address:['',Validators.required],
      
      username: ['', Validators.email],
      password: ['', Validators.required] 

    });


    
  }
  savechanges()
  {
    console.log(this.form.value);
    this.customer.address=this.form.get('address').value;
    this.customer.emailId=this.loggedPerson.emailId;
    this.customer.mobileNumber=this.form.get('phonenumber').value;
    this.customer.name=this.form.get('name').value;
    this.customer.password=this.form.get('password').value;
    this.customer.phoneNumber=this.form.get('phonenumber').value;
    if(this.loggedPersonRole=="customer")
    {
      this.customerService.editProfiile(this.customer).subscribe((data)=>{
        if(data!=null)
        {
          this.customerService.saveLoggedPerson(data);
          this.EditMode=false;
        }
      })

    }

     if(this.loggedPersonRole=="washer")
     {
       this.washerservice.updateprofile(this.customer).subscribe((data)=>{
         if(data!=null)
         {
           this.washerservice.saveLoggedPerson(data);
           this.EditMode=false;
         }
       })
     }

  }

  changeMode()
  {
    this.EditMode=true;
  }

  getback()
  {
    this.route.navigateByUrl('');
  }

}

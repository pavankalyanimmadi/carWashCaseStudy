import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-all-customers',
  templateUrl: './admin-all-customers.component.html',
  styleUrls: ['./admin-all-customers.component.scss']
})
export class AdminAllCustomersComponent implements OnInit {
  allCustomers:any;
  dataSource:MatTableDataSource<any>;
  displayedColumns: string[] = ['emailId','name','address','mobileNumber','password','delete',];
  searchKey:string;
  @Output() refresh: EventEmitter<any> = new EventEmitter();

  constructor(private adminService:AdminService)
  { }

  ngOnInit(): void {
    this.gettingdata();

  }

  gettingdata()
  {
    this.adminService.getallCusttomers().subscribe((data)=>{
      this.allCustomers=data;
      console.log(this.allCustomers);
      this.dataSource=new MatTableDataSource(this.allCustomers);
    })
  }

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    console.log(searchKey)
    this.dataSource.filter = searchKey.trim().toLowerCase();
    console.log("in data source  "+ this.dataSource.filter)
  }

  addnewCustomer()
  {
    

  }

  deletecustomer(customer)
  {
    console.log(customer);
  this.adminService.deleteCustomer(customer).subscribe((data)=>{
    if(data!=null)
    {
    console.log(data);
      this.gettingdata();
      this.refresh.emit();
    }
  })

    
  }



}

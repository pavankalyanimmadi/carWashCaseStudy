import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {CustomerService} from '../customer.service'
import { Car } from '../Car';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { AddingcarsComponent } from '../addingcars/addingcars.component';
import { ThrowStmt } from '@angular/compiler';
import { Router } from '@angular/router';
import { CustomerRaiseRequestComponent } from '../customer-raise-request/customer-raise-request.component';

@Component({
  selector: 'app-customer-cars',
  templateUrl: './customer-cars.component.html',
  styleUrls: ['./customer-cars.component.scss']
})
export class CustomerCarsComponent implements OnInit {

  base64Data: any;
  image: any;
  cardelete:Car=new Car();

  
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();

  data:Car[]=null;


  constructor(private customerService:CustomerService, public dialog: MatDialog ,private route :Router) { }

  ngOnInit(): void {
    
    this.data=this.customerService.loggedPerson.cars;
    for(let i in this.data){
      this.image=this.data[i].image
      this.data[i].image='data:image/jpeg;Base64,' + this.image;
 
    }
    console.log(this.data);
    

  }

  getdata()
  {
    
    this.data=this.customerService.loggedPerson.cars;
    for(let i in this.data){
      this.image=this.data[i].image
      this.data[i].image='data:image/jpeg;Base64,' + this.image;
 
    }
    console.log(this.data);

  }

  addcar()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe((data)=>{
      
      this.getdata();
      this.getLoggedInName.emit();
      
    })
    this.dialog.open(AddingcarsComponent,dialogconfig);
  }


  bookwash(car)
  {
    this.customerService.selectedcar(car);
    console.log(car);
    
      this.route.navigateByUrl('customerraisingrequest');
    

    
      
    
    
  }


  deletecar(car)
  {
      console.log(car);
      this.cardelete.customerId=localStorage.getItem('id');
      this.cardelete.carModel=car.carModel;
      this.cardelete.carNumber=car.carNumber;
        console.log("cal delete");
        console.log(this.cardelete)

      this.customerService.deletecar(this.cardelete).subscribe((data)=>{
        if(data!=null)
        {
          console.log(data)
          this.customerService.saveLoggedPerson(data);
          this.getdata();
          this.getLoggedInName.emit();

        }

      })
  }

}
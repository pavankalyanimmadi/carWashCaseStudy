import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-all-washers',
  templateUrl: './admin-all-washers.component.html',
  styleUrls: ['./admin-all-washers.component.scss']
})
export class AdminAllWashersComponent implements OnInit {

  allWashers:any;
  dataSource:MatTableDataSource<any>;
  displayedColumns: string[] = ['emailId','name','address','mobileNumber','password','delete',];
  searchKey:string;
  @Output() refresh: EventEmitter<any> = new EventEmitter();

  constructor(private adminService:AdminService)
  { }

  ngOnInit(): void {
    this.gettingdata();

  }

  gettingdata()
  {
    this.adminService.getAllWashers().subscribe((data)=>{
      this.allWashers=data;
      console.log(this.allWashers);
      this.dataSource=new MatTableDataSource(this.allWashers);
    })
  }

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    console.log(searchKey)
    this.dataSource.filter = searchKey.trim().toLowerCase();
    console.log("in data source  "+ this.dataSource.filter)
  }

  addnewCustomer()
  {
    

  }

  deletecustomer(washer)
  {
    console.log(washer);
  this.adminService.deletewasher(washer).subscribe((data)=>{
    if(data!=null)
    {
    console.log(data);
      this.gettingdata();
      this.refresh.emit();
    }
  })

    
  }

}

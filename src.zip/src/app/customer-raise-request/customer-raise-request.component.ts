import { Component, OnInit, ɵConsole } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {AdminService} from '../admin.service'
import {WashOrder} from '../WashOrder'
import {CustomerService} from '../customer.service'
import {formatDate} from '@angular/common';
import { Router } from '@angular/router';
import { Car } from '../Car';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CustomerCarsComponent } from '../customer-cars/customer-cars.component';
import { WashPackage } from '../washPackage';

@Component({
  selector: 'app-customer-raise-request',
  templateUrl: './customer-raise-request.component.html',
  styleUrls: ['./customer-raise-request.component.scss']
})
export class CustomerRaiseRequestComponent implements OnInit {

  base64Data: any;
  image: any;
  selectedCar:Car=new Car();
  customerallcars:Car[];
  selectedPackage:WashPackage=new WashPackage();

  form:FormGroup;
  washPackages:any
  cars:String[]=['ferrari','ford','tyota','tata','duster'];
  minDate:Date=new Date(); 
  value:any;
  booktime:Date;

  order:WashOrder=new WashOrder();


  constructor(private fb:FormBuilder,private packService:AdminService,private custmerService:CustomerService,private route :Router,public dialog: MatDialog ) { }

  ngOnInit(): void {
    this.form=this.fb.group({
      car:['',Validators.required],
      carNumber:['',Validators.required],
      washPackage: ['', Validators.required],
      bookingdate: ['', Validators.required] ,
      bookingtime: ['', Validators.required],
      location:['',Validators.required]

    });

    this.custmerService.getAllPackages().subscribe((data)=>{
      this.washPackages=data
      console.log(data) 
    })

     this.customerallcars=this.custmerService.loggedPerson.cars;
     






    if(this.custmerService.isSelectedCar)
    {
      this.selectedCar=this.custmerService.selectedCarForWash;
      console.log("car got selected");
      console.log(this.selectedCar);

    }

    console.log("package got selected")

   if(this.custmerService.isselectedpackage)
   {
    this.selectedPackage=this.custmerService.selectedpackgeforwash;
   }
    
    

    }

    onSubmit()
    {

      console.log(this.form.value);

      this.booktime=this.form.get('bookingtime').value
      var x=this.booktime.toLocaleString();
      

      var y=x.slice(10,); 

      


      

        
      


      var val = this.form.get('bookingdate').value;
       val = formatDate(val,'dd/MM/yyyy','en');
      this.order.carNumber=this.form.get('car').value;
      this.order.customerId=localStorage.getItem('id')
      this.order.date=val;
      this.order.location=this.form.get('location').value;
      this.order.pakcageId=this.form.get('washPackage').value;
      this.order.time=y;
      for(let carx of this.customerallcars)
      {
        if(carx.carNumber==this.order.carNumber)
        {
          this.order.carModel=carx.carBrandName+" "+carx.carModel;
        }

      }


       console.log(this.order);
     this.custmerService.customerRaiseRequest(this.order).subscribe((data)=>{
        console.log("response")
      console.log(data);
      this.route.navigateByUrl('/customerinprogressrequests');


      })

      

    }

    

    


}

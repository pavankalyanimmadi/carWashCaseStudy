import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentmethods',
  templateUrl: './paymentmethods.component.html',
  styleUrls: ['./paymentmethods.component.scss']
})
export class PaymentmethodsComponent implements OnInit {

  cards:any=[{cardNumber:"123456789098", nameOnCard:"pavann kalyan",cardExpireDate:"09/22"},{cardNumber:"123456789098", nameOnCard:"kalyan",cardExpireDate:"03/26"},
  {cardNumber:"123456789098", nameOnCard:"kalyan",cardExpireDate:"03/26"},{cardNumber:"123456789098", nameOnCard:"kalyan",cardExpireDate:"03/26"},
]
  constructor() { }

  ngOnInit(): void {
  }

}

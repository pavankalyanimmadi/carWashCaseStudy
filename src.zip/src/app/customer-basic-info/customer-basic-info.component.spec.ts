import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerBasicInfoComponent } from './customer-basic-info.component';

describe('CustomerBasicInfoComponent', () => {
  let component: CustomerBasicInfoComponent;
  let fixture: ComponentFixture<CustomerBasicInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerBasicInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerBasicInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

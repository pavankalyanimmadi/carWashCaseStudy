import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-basic-info',
  templateUrl: './customer-basic-info.component.html',
  styleUrls: ['./customer-basic-info.component.scss']
})
export class CustomerBasicInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
